// help with AI
import Foundation

func fetchStory() {
    let prompt = "write me a 5 sentence story each on a seperate line and another sentence describing each sentence so that it is easy to generate an image based on the text inside curly braces in the same line"
    let encodedPrompt = prompt.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
    let urlString = "https://text.pollinations.ai/\(encodedPrompt)"
    
    guard let url = URL(string: urlString) else {
        print("Invalid URL")
        return
    }

    let task = URLSession.shared.dataTask(with: url) { data, response, error in
        if let error = error {
            print("Error fetching data: \(error.localizedDescription)")
            return
        }
        
        guard let data = data else {
            print("No data received")
            return
        }
        
        if let responseString = String(data: data, encoding: .utf8) {
            print("Response: \(responseString)")
        } else {
            print("Failed to decode response")
        }
    }
    
    task.resume()
}

// Call the function
fetchStory()
