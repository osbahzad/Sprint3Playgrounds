// some help from AI
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let mistake = "test"
let url = "https://api.dictionaryapi.dev/api/v2/entries/en/\(mistake)"

struct Phonetic: Decodable {
    let text: String?
    let audio: String?
}

struct Result: Decodable {
    let word: String
    let phonetics: [Phonetic]?
}

let task = URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
    guard let data = data else {
        print("Error: No data to decode")
        return
    }
  
    do {
        let results = try JSONDecoder().decode([Result].self, from: data)
        
        if let firstResult = results.first {
            print("Word: \(firstResult.word)")
            if let phonetic = firstResult.phonetics?.first(where: { $0.audio != nil }) {
                print("Audio URL: \(phonetic.audio ?? "No audio available")")
            } else {
                print("No phonetic audio available")
            }
        } else {
            print("No results found")
        }
    } catch {
        print("Error: Couldn't decode data into a result - \(error.localizedDescription)")
    }
}

task.resume()
