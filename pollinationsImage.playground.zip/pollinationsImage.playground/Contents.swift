// help from AI
import UIKit
import PlaygroundSupport

func fetchImage() {
    let prompt = "an image of a cartoonish gray cat"
    let encodedPrompt = prompt.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
    let urlString = "https://image.pollinations.ai/prompt/\(encodedPrompt)"
    
    guard let url = URL(string: urlString) else {
        print("Invalid URL")
        return
    }

    let task = URLSession.shared.dataTask(with: url) { data, response, error in
        if let error = error {
            print("Error fetching image: \(error.localizedDescription)")
            return
        }
        
        guard let data = data else {
            print("No data received")
            return
        }
        
        if let image = UIImage(data: data) {
            DispatchQueue.main.async {
                // Display the image in a UIImageView
                let imageView = UIImageView(image: image)
                imageView.contentMode = .scaleAspectFit
                imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
                
                // Set the live view to display the image
                PlaygroundPage.current.liveView = imageView
            }
        } else {
            print("Failed to decode image")
        }
    }
    
    task.resume()
}

// Call the function
fetchImage()
